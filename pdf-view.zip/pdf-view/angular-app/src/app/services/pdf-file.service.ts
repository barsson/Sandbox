import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PdfFileService {

  constructor(private httpClient: HttpClient) { }

  getPdfFile(){
    return this.httpClient.get('');
  }
}
