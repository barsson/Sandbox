import { TestBed } from '@angular/core/testing';

import { PdfFileService } from './pdf-file.service';

describe('PdfFileService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PdfFileService = TestBed.get(PdfFileService);
    expect(service).toBeTruthy();
  });
});
