import { Component, OnInit, ViewChild, ElementRef, ContentChild } from '@angular/core';
import {TabViewModule} from 'primeng/tabview';
import {DropdownModule} from 'primeng/dropdown';
import { NgxExtendedPdfViewerService, NgxExtendedPdfViewerComponent } from 'ngx-extended-pdf-viewer';
import {PdfFileService} from '../../services/pdf-file.service';

@Component({
  selector: 'app-policy-form',
  templateUrl: './policy-form.component.html',
  styleUrls: ['./policy-form.component.css'],
  providers: [NgxExtendedPdfViewerComponent]
})
export class PolicyFormComponent implements OnInit {
  firstName: any = '';
  plans: any;
  public filePathAndName = "../../../assets/test.pdf";
  constructor(private pdfFileService: PdfFileService) {
    this.plans = [
            {label:'1 Year', value:null},
            {label:'2 Year', value:null},
            {label:'3 Year', value:null},
            {label:'4 Year', value:null}
        ];
   }

  ngOnInit() {
    this.filePathAndName = "../../../assets/test.pdf"
  }

  public onFocusEvent() {
    this.pdfFileService.getPdfFile().subscribe((data: any) =>{
      this.filePathAndName = '';
      this.filePathAndName = '../../../assets/test.pdf';
    }); 
    // generate random number b/w 1 and 6 and load {number}.pdf file
    /* var number = Math.min(Math.ceil( Math.random()* 10), 6);
    this.filePathAndName = `../../../assets/`+number+`.pdf`; */
    
  }

}